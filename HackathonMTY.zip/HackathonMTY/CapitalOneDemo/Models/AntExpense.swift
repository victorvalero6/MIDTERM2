// Modelo para gastos hormiga
import Foundation

struct AntExpense: Identifiable {
    let id = UUID()
    let tx: Tx
}
